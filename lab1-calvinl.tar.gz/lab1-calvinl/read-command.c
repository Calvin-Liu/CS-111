#include "alloc.h"
#include "command.h"
#include "command-internals.h"
#include <error.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

//keeps track of line number for error messages
int lineNumber;
//poitners used to get bytes from stream/ call functions
int (*get_byte) (void *);
void *stream;

command_t createCommand(char* TokenString, enum command_type type);
command_t subshellCommand(char* TokenString);
typedef struct node *command_node_t;



//struct that will hold the command and have pointers to simplify printing
struct node
{
  command_t command;
  command_node_t next;
  command_node_t prev;
};




//struct used
struct command_stream
{
  command_node_t* commands;
};



//return nonzero if character c is valid for simplecommand
int isValidCharacterForProject ( char c)
{
   return ((c == '!')
   || (c == '%') 
   || (c == '+') 
   || (c == ',')
   || (c == '-')
   || (c == '.')
   || (c == '/')
   || (c == ':')
   || (c == '@')
   || (c  == '^')
   || (c == '_')
   || (c == ' ')
   || (c == '\n')
   || (c == '\t')
   || (c>=65 && c <=90)
   || ( (c >= '0') && (c <= '9') )
   || (c>= 97 && c <=122));
}

int isValidNoTabNoSpace ( char c)
{
   return ((c == '!')
   || (c == '%')
   || (c == '+')
   || (c == ',')
   || (c == '-')
   || (c == '.')
   || (c == '/')
   || (c == ':')
   || (c == '@')
   || (c  == '^')
   || (c == '_')
   || (c == '\n')
   || (c>=65 && c <=90)
   || ( (c >= '0') && (c <= '9') )
   || (c>= 97 && c <=122));
}



//function that will remove all blank characters, while keeping track of line number 
void removeSpaces()
{
  char c = get_byte(stream);
  if(c != EOF)
  {
    //check for blank spaces
    while( (c == '\n') || (c == '\t') || (c == ' ')) //adding (c == ' ') will make an infinite loop
    {
      //if newline, update the count
      if(c == '\n')
        lineNumber++;
      c = get_byte(stream);
    }
    ungetc(c, stream);
  }
  else
    ungetc(c, stream);
}

//checks for EOF, if character is not EOF, rturn the byte
int isItEndOfFile(void* stream)
{
   char c = get_byte(stream);
   if(c == EOF)
   {
	return 1;
   }
   else
   {
      ungetc(c, stream);
      return 0;
   }
}

//FIX ME:
//int stringLength;

//this return a command_type token based off of the bytes in the command
//checks for every case and prompts errors when necessary
enum command_type
get_type(char *TokenString)
{
  while(!isItEndOfFile(stream))
  {
    //two characters that will keep track of the next bytes, secondChar is primarily used for binary operators
    char firstChar = get_byte(stream);
    char secondChar = get_byte(stream);
	//if there is a comment right after newline, that is an error
    if( secondChar == '#' && !( (firstChar== '\n') || (firstChar == '\t') ) )
      error(1, 0, "%d : There can't be a hashtag after the newline or tab", lineNumber);
	 //each time we use the second character, we need to unget the character
    ungetc(secondChar, stream);
	
	//if we reached EOF
    if (firstChar == EOF)
        return SIMPLE_COMMAND;
	//implement a comment function, continue to new line
    else if (firstChar == '#')
    {
        secondChar = get_byte(stream);
		//erase everything up to a new line
        while(secondChar != '\n')
        {
            if(secondChar == EOF)
              return SIMPLE_COMMAND;
            secondChar = get_byte(stream);
        }
        return get_type(TokenString);
    }
	//check for AND_COMMAND
    else if (firstChar == '&')
    {
		//check for second &
        secondChar = get_byte(stream);
        if(secondChar == '&')
        {
	  char thirdChar;
	  thirdChar = get_byte(stream);
	  if (thirdChar =='&')
	  {
		 error(1, 0, "%d : Too many '&' symbols", lineNumber);
	  }
	  else
	  {
		ungetc(thirdChar, stream);
	  }
          removeSpaces();
          return AND_COMMAND;
        }
		//if there isnt a second &, that is a bug for an unknown character
        else if(secondChar == EOF)
          error(1, 0, "%d : Must have a second '&' symbol", lineNumber);
        else 
          ungetc(secondChar, stream);
     }
	 //the start of a SUBSHELL_COMMAND
     else if (firstChar == '(')
     {
        removeSpaces();
        return SUBSHELL_COMMAND;
     }
	 //the end of a SUBSHILL_COMMAND, so the command
     else if (firstChar ==')')
	 {
        ungetc(firstChar, stream);
        return SIMPLE_COMMAND;
     }
	 //the PIPE or OR_COMMAND
     else if (firstChar == '|')
     {
		//if the next character is an OR
        secondChar = get_byte(stream);
        if(secondChar == '|')
        {
			char thirdChar;
			thirdChar = get_byte(stream);
			if (thirdChar == '|')
			{
				error(1, 0, "%d : Too many '|' symbols", lineNumber);
			}
          removeSpaces();
          return OR_COMMAND;
		  //no need to ungetC becuase we consume that ||
        }
		//check if there is a word or SIMPLE_command after the |, that signifies a pipe
        else if(isValidCharacterForProject(secondChar))
        {
			//we dont' want to consume that extra character yet
          ungetc(secondChar, stream);
          removeSpaces();
          return PIPE_COMMAND;
        }
        else if(secondChar == EOF)
          error(1, 0, "%d : Must have a second '|' symbol", lineNumber);
     }
	//check for new line
     else if (firstChar == '\n') 
     {
		lineNumber++;
		return SIMPLE_COMMAND;
     }
	//check for semicolon
     else if (firstChar ==';')
		return SIMPLE_COMMAND;
     else 
//     {
	//FIX ME:
//	if(firstChar == '>' || firstChar == '<')
//        {
//	   int index = strlen(TokenString);
//	   index--;
//	   while(TokenString[index] == ' ')
//	   {
//		index--;
//		stringLength--;
//	   }
//	}
//	 TokenString[stringLength] = firstChar;
//	 stringLength++;
//     }
	TokenString[strlen(TokenString)] = firstChar;
   }
   return SEQUENCE_COMMAND;
}
 



//helper function that creates a simple command based on the list of charcters read by the command_stream
command_t
make_simple_command(char *TokenString)
{
  if(!strlen(TokenString))
    error(1, 0, "%d : You need to make at least one simple command", lineNumber);
	//create the command and initiallize its values
  command_t command = checked_malloc(sizeof(struct command));
  command->type = SIMPLE_COMMAND; 
  command->status = -1;
  command->input = 0;
  command->output = 0;
  command->u.word = checked_malloc(20*sizeof(char*));
  
  //simple commands may be commands with input and output
  //we need logic in order to compensate for this
  size_t simpleCmdSize = 20;
  size_t input_size = 20;
  size_t output_size = 20;      
  size_t currentWordLength; 
  size_t index = 0;
 
  bool in_word = false;
  bool thereIsAnInput = false;
  bool thereIsAnOutput = false;
  bool input = false; 
  bool output = false;
 
  int i;
  //loop though to analyze each token
  for(i = 0; TokenString[i]; i++)
  {
	//if we need to input a file, we should set a flag to treat the next characters seperately
    if(TokenString[i] == '<')
    {
       if(i == 0 || input || output || thereIsAnInput || thereIsAnOutput)
         error(1, 0, "%d : There must be something valid to redirect for input", lineNumber);
       command->input = checked_malloc(20*sizeof(char));
       thereIsAnInput = true;
    }
	//same goes for an output
    else if(TokenString[i] == '>')
    {
       if(i == 0 || output || thereIsAnOutput)
         error(1, 0, "%d : There must be something valid to redirect for output", lineNumber);
       command->output = checked_malloc(20*sizeof(char)); 
       thereIsAnInput = false;
       thereIsAnOutput = true;
    }
	//if the character is a valid character, then we can create a file, or an executable
    else if(isValidNoTabNoSpace(TokenString[i]))
    {
		// if we are adding words to an input, treat the characters separately
      if(thereIsAnInput)
      {
        input = true;
        char* string = command->input;
		// if the string has overflowed the size, we need to reallocate the string
        if(strlen(string) >= input_size)
          checked_grow_alloc(string, &input_size);
	
        string[strlen(string)] = TokenString[i];
      }
		//similar case for output
      else if(thereIsAnOutput)
      {
        output = true;
	char* string = command->output;
        if(strlen(string) >= output_size)
          checked_grow_alloc(string, &output_size);
       string[strlen(string)] = TokenString[i];
      }
	  //if it is not an output or an input, then we have to make a word.
      else if(!in_word)
      {
	//if a word has not been created, and we are not part of the input or output, create a new command to store
        if((input || output) && !thereIsAnInput && !thereIsAnOutput)
          error(1, 0, "Syntax Error: Line %d", lineNumber);
        if(index >= simpleCmdSize)
          checked_grow_alloc(command->u.word, &simpleCmdSize);
        command->u.word[index] = checked_malloc(20*sizeof(char));
        currentWordLength = 20;
        command->u.word[index][0] = TokenString[i];
        in_word = true;
      }      
	  //if the word has already existed, append to the word 
      else if(in_word)
      {
        char *string = command->u.word[index];
        if(strlen(string) >= currentWordLength)
          checked_grow_alloc(string, &currentWordLength);
	string[strlen(string)] = TokenString[i];
      }
    }
	//if there are blank spaces
    else if( (TokenString[i] == '\t') || (TokenString[i] == ' ') )
    {
		//we're in a word, the blank space signifies the end of a word
      if(in_word)
      {
        in_word = false;
        index++;
      }
	  //we reached the end of an input
      else if(input && thereIsAnInput)
        thereIsAnInput = false;
		// we reached the end of an output
      else if(output && thereIsAnOutput)
        thereIsAnOutput = false;
	// remove space, the test output doesn't have the space
	int h =0;
int j =0;	 
    }
	//if we reached the end of file, we can close the command, and prepare to return
    else if(TokenString[i] == EOF)
    {
      if(index >= simpleCmdSize)
        checked_grow_alloc(command->u.word, &simpleCmdSize);
      return command;
    }
    else
      error(1, 0, "%d : No valid symbol used", lineNumber);
  }
  memset((void *) TokenString, '\0', 1024);
  if(index >= simpleCmdSize)
        checked_grow_alloc(command->u.word, &simpleCmdSize);
  return command;
}






//this function makes a compound_command - these are binary commands PIPE AND OR
//there are special cases when we are in a subshell command
//the main things to look for is if we happen upon a subshell, a pipe after a non pipe
command_t
make_compound_command(char *TokenString, enum command_type type, command_t caller)
{
	//create new command
  command_t compound_command = checked_malloc(sizeof(struct command));
  compound_command->type = type;
  compound_command->status = -1; 
   //if there is no subshell command, we can worry less
  if(caller == 0)
    compound_command->u.command[0] = make_simple_command(TokenString);
	
	//if there is a subshell command, :C
  else if(caller->type == SUBSHELL_COMMAND || (type != PIPE_COMMAND && caller->type == PIPE_COMMAND) || ((type == PIPE_COMMAND) == (caller->type == PIPE_COMMAND)))
  //point the one pointer to the caller, be it what it may
    compound_command->u.command[0] = caller;
	
	
	//we have a pipe after another command
  else if(type == PIPE_COMMAND && caller->type != PIPE_COMMAND)
    compound_command->u.command[0] = caller->u.command[1];
	
	//get the next token to assign u.command[1]
  enum command_type next_type = get_type(TokenString);
  
  //if the next command is a word, it is simple to implement
  if(next_type == SIMPLE_COMMAND || next_type == SEQUENCE_COMMAND)
  {
    compound_command->u.command[1] = make_simple_command(TokenString);
    return compound_command;
  }
  
  //subshells need to be treated seperately
  else if(next_type == SUBSHELL_COMMAND)
  {
    command_t subshell = subshellCommand(TokenString);
    next_type = get_type(TokenString);
	//if the next type within the subshell is a simple command point to the subshell, no further action
    if(next_type == SIMPLE_COMMAND)
    {
      compound_command->u.command[1] = subshell;
      return compound_command;
    }
	//if the current is not a pipe, but the next one is after the subshell
    else if(type != PIPE_COMMAND && next_type == PIPE_COMMAND)
    {
      compound_command->u.command[1] = subshell;
      compound_command->u.command[1] = make_compound_command(TokenString, PIPE_COMMAND, compound_command);
      return compound_command;
    }
    else
    {
      compound_command->u.command[1] = subshell;
      command_t next_command = make_compound_command(TokenString, next_type, compound_command);
      return next_command;
    }
  }
  
  else if(type != PIPE_COMMAND && next_type == PIPE_COMMAND)
  {
    compound_command->u.command[1] = make_simple_command(TokenString);
    compound_command->u.command[1] = make_compound_command(TokenString, PIPE_COMMAND, compound_command);
    return compound_command;
  }
  else
  {
    compound_command->u.command[1] = make_simple_command(TokenString);
    command_t next_command = make_compound_command(TokenString, next_type, compound_command);
    return next_command;
  }
}






//creates a subshell command
command_t
subshellCommand(char *TokenString)
{
	//creates the command object and initiallize
  command_t subshell = checked_malloc(sizeof(struct command));
  subshell->type = SUBSHELL_COMMAND; 
  subshell->status = -1;
  //subshell collects a linked list of commands
  enum command_type type = get_type(TokenString);
  command_t command = createCommand(TokenString, type);
  removeSpaces();
  
  //the end of the substring occurs when the next character is right paranthases
  char c;
  if((c = get_byte(stream)) == ')')
  {
    subshell->u.subshell_command = command;
    return subshell;
  }
  //there are commands we need to add, we keep running until we reach right parantheses 
  else
  {
	//all commands are SEQUENCED
    ungetc(c, stream);
    command_t top = checked_malloc(sizeof(struct command)); 
    top->type = SEQUENCE_COMMAND; 
	top->status = -1;
    top->u.command[0] = command; 
	top->u.command[1] = 0;
	//keep reading bytes until you reach  right parantheses
    while((c = get_byte(stream)) != ')')
    {
      ungetc(c,stream);
      enum command_type type = get_type(TokenString);
      command_t new_sequence = checked_malloc(sizeof(struct command));
      new_sequence->type = SEQUENCE_COMMAND; 
	  new_sequence->status = -1;
      new_sequence->u.command[0] = createCommand(TokenString, type);
      new_sequence->u.command[1] = 0;
	  
	  //temporary command that will help iterate without changing top
      command_t bottom = top;
	  //iterate to the endo fthe linked list
      while(bottom->u.command[1] != 0)
        bottom = bottom->u.command[1];
	  //once we reached the endof the linked list, we append the new command to it
      bottom->u.command[1] = new_sequence;
    }
	//after we reached the end of the subshell command, we can finallize and
    command_t bottom = top;
    while(bottom->u.command[1]->u.command[1] != 0)
      bottom = bottom->u.command[1];
    bottom->u.command[1] = bottom->u.command[1]->u.command[0];
	//add the linked list of SEQUENCE commands to the subhsell
    subshell->u.subshell_command = top;
    return subshell;
  }
}





//helper function that will fork the program towards the right function depending on the type
command_t
createCommand(char* TokenString, enum command_type type)
{
	//creates a SIMPLE
  if(type == SIMPLE_COMMAND)
    return make_simple_command(TokenString);
	//creates a subshell
  else if(type == SUBSHELL_COMMAND)
  {
    command_t subshell = subshellCommand(TokenString);
    type = get_type(TokenString);
	//if the next commnad is a simple_command, we can return the subshell
    if(type == SIMPLE_COMMAND)
      return subshell;
    else
	//we must treat every compound command in side a subshell differently
      return make_compound_command(TokenString, type, subshell);
  }
  else
    return make_compound_command(TokenString, type, 0);
}







command_node_t
createNewNode(char* TokenString, enum command_type type)
{
//creates a blank node
  command_node_t node = checked_malloc(sizeof(struct  node));
  node->next = NULL;
  //calls the make command fucntion
  node->command = createCommand(TokenString,type);
  return node;
}










//this stream attaches what is given through the main function and 
command_stream_t
make_command_stream (int (*get_next_byte) (void *),
                     void *get_next_byte_argument)
{
  lineNumber = 1;
  char TokenString[1024] = "";
  //FIX ME:
//  stringLength = 0;
  get_byte = get_next_byte;
  stream = get_next_byte_argument;
  //create a stream to be used to keep track of the commands
  command_stream_t stream_t = checked_malloc(sizeof(struct command_stream));
  command_node_t node = checked_malloc(sizeof(struct node));
  //create a node 
  command_node_t temp_node = node;
  command_node_t head = NULL;    
  command_node_t tail = NULL;
  
  //starts to read from the commands, 1 byte at a time
  if(!isItEndOfFile(stream))
  {
	//if we remove empty spaces
    removeSpaces();
    if((TokenString[0] = get_byte(stream)) == EOF)
    {
      free(stream_t);
      free(node);
      return NULL;
    }
    ungetc(TokenString[0], stream);
	//initiallize the list of token list that will hold the bytes
    TokenString[0] = '\0';
	//get the first command_type token
    enum command_type type = get_type(TokenString);  

	//iterates indefinately until we reach the EOF or if an error prompts during the process
    while(true)  
    {
	//creates corresponding command
      if(type == SEQUENCE_COMMAND)
        temp_node = createNewNode(TokenString, SIMPLE_COMMAND);
      else
        temp_node = createNewNode(TokenString, type);        
		
	//start reassigning the pointer of the stream
	//if head hasn't been created yet, assign it
      if(!head)
      {
              head = temp_node;
      }
	  //update the head
      else
      {
        tail->next = temp_node;
        temp_node->prev = tail;
      }
	  //update the tail
      tail = temp_node;
	  
	  //the first exit case depends on the token returned
      if(type == SEQUENCE_COMMAND)
        break;
      removeSpaces();
	  //if we reach EOF, the stream has finished making commmands, and is ready
	  //this is one of two exit cases out of the while loop
      if((TokenString[0] = get_byte(stream)) == EOF)
      {
		//sets up the stream pointer to head
        stream_t->commands = &head;
        return stream_t;
      }
      ungetc(TokenString[0], stream);
      TokenString[0] = '\0';
      type = get_type(TokenString);
    }
  }
  stream_t->commands = &head;
  return stream_t;
}



command_t
read_command_stream (command_stream_t s)
{
	//this occurs when we get an empty file, no stream exists
	if (s == NULL) return NULL;
	//if we have reached the end of the linked list
  if(*(s->commands) == NULL) return NULL;
  //move the command pointer toward the end of the list
  else 
  {
	command_node_t stream_t = *(s->commands);
	//reassign the head pointer
    *(s->commands) = stream_t->next;
	//free data as we increment through the 
    if(stream_t->prev != NULL)
    {
      free(stream_t->prev->command);
      free(stream_t->prev);
    }
    return stream_t->command;
  }
}
