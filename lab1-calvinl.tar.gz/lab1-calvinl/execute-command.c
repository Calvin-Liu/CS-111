// UCLA CS 111 Lab 1 command execution

#include "command.h"
#include "command-internals.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>
#include <error.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>

/* FIXME: You may need to add #include directives, macro definitions,
   static function definitions, etc.  */

/*

void removeExec(command_t c, int position)
{
	if(c->u.word[position] == "exec")
	{
	   removeExec(c, position+1);
	}
	else
	{
	   execvp(c->u.word[position], c->u.word+position)
	}
}

*/

void justExecute(command_t c);

int
command_status (command_t c)
{
  return c->status;
}

void andCommand(command_t c)
{
	justExecute(c->u.command[0]); //work on the first subcommand
	if(c->u.command[0]->status == 0) //if it was successful
	{
		justExecute(c->u.command[1]); //recurse for the second part of the word and on
		c->status = c->u.command[1]->status;
	}
	 //set the status as you go down the tree, similar to forking and getting the exit status
	else
		c->status = c->u.command[0]->status;
}

void orCommand(command_t c)
{
	justExecute(c->u.command[0]);
	if(c->u.command[0]->status != 0) //if it was successful
        {
                justExecute(c->u.command[1]); //recurse for the second part of the word and on
                c->status = c->u.command[1]->status;
        }
	//set the status as you go dwn the tree, similar to forking and getting the exit status
        else
                c->status = c->u.command[0]->status;
}

//not too sure if you have to fork for seq or if is very similar to and/or
void seqCommand(command_t c)
{
	justExecute(c->u.command[0]);  //feed the left child to the justExecute command
	justExecute(c->u.command[1]); //feed the right child to the justExecute command
	c->status = c->u.command[1]->status;	//set the status of the command based on the finished recursion
}

void pipeCommand(command_t c)
{
	int pipefd[2];
	int status;
	pid_t firstPID;
	if(pipe(pipefd) == -1)
		error(1, 0, "Pipe system call not working");
//	pipe(pipefd);
	firstPID = fork();
	if(firstPID == 0) //it is a child
	{
		close(pipefd[1]);
		if( dup2(pipefd[0], 0) == -1)
			error(1, 0, "Could not dup pipefd[0] to 0");
//		dup2(pipefd[0], 0);
		justExecute(c->u.command[1]);
		c->u.command[1]->status = WEXITSTATUS(status);
	}
	else
	{
		close(pipefd[0]);
//		if( dup2(pipefd[1], 1) == -1)
//			error(1, 0, "Could not dup pipefd[1] to 1");
		dup2(pipefd[1], 1);
		justExecute(c->u.command[0]);
	}
}

void inANDout(command_t c)
{
	if(c->input != NULL)
	{
		int IN = open(c->input, O_RDONLY);
		if(IN == -1)
		{
			error(1, 0, "Could not open the file: %s", c->input);
		}
		if( dup2(IN, 0) == -1)
			error(1, 0, "Could not dup IN to 0");
		close(IN);
	}
	if(c->output != NULL)
	{
		int OUT = open(c->output, O_WRONLY | O_CREAT, (S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IROTH) );
		if(OUT == -1)
		{
			error(1, 0, "Could not open the file: %s", c->output);
		}
		if( dup2(OUT, 1) == -1)
			error(1, 0, "Could not dup OUT to 1");
		close(OUT);
	}
}

//Just added, needs more testing
bool nestedSubshell = false;
void sshellCommand(command_t c)
{
	if(c->u.subshell_command->type == SUBSHELL_COMMAND)
	{
		nestedSubshell = true;
	}
	if(nestedSubshell == false)
	{
		justExecute(c->u.subshell_command);
		c->status = c->u.subshell_command[1].status;	
	}
}


void simpleCommand(command_t c)
{
	pid_t firstPID = fork();
	if(firstPID == 0)
	{
		inANDout(c);
		execvp(c->u.word[0], c->u.word);
	}
	else
	{
		int status;
		waitpid(firstPID, &status, 0);
		c->status = WEXITSTATUS(status);
	}
}

void justExecute(command_t c)
{
       switch(c->type)
       {
         case AND_COMMAND:
		andCommand(c);
	    break;

         case SEQUENCE_COMMAND:
		seqCommand(c);
            break;

         case OR_COMMAND:
		orCommand(c);
            break;

         case PIPE_COMMAND:	
		pipeCommand(c);	
            break;

         case SIMPLE_COMMAND:
		simpleCommand(c);
            break;

         case SUBSHELL_COMMAND:
		sshellCommand(c);
        }	
}


/*

another way to do the case statement
case AND_COMMAND:
	int statusChild;
	PID = fork();
	if(PID == 0)
	{
		justExecute(c->u.word[0]);
	}
	else
	{
		waitpid(pid, &status, 0);
		statusChild = W_EXITSTATUS(status);
	}

*/

void uselessFunction (int time_travel)
{
	if (time_travel == 0)
		 return;
}

void
execute_command (command_t c, int time_travel)
{

/*   
  FIXME: Replace this with your implementation.  You may need to
     add auxiliary functions and otherwise modify the source code.
     You can also use external functions defined in the GNU C Library.  
*/
	uselessFunction(time_travel);
	justExecute(c);

//  error (1, 0, "command execution not yet implemented");
}

