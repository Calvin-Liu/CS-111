#!/bin/bash

echo @@@@@@@@@@@@@@@@@@@@@@@@@@@Just one simple command@@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash simpleScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@@@@AND command@@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash andScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@@@@2 AND command@@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash twoAndScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@@@@OR command@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash orScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@@@@SUBSHELL command@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash subshellScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@@@@SEQUENCE command@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash sequenceScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@@@NEW FILE AND A COMMAND@@@@@@@@@@@@@@@@@@@@@@@
./timetrash newFileScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@@OPEN FILE AND A COMMAND@@@@@@@@@@@@@@@@@@@@@
./timetrash openFileScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@PIPE@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash pipeScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@@Two line script@@@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash twoLineScript.sh
echo @@@@@@@@@@@@@@@@@@@@@@@Is cat echoing to screen?@@@@@@@@@@@@@@@@@
./timetrash screenTest.sh
#echo @@@@@@@@@@@@@@@@@@@@@@@pipe on a different line@@@@@@@@@@@@@@@@@@
#./timetrash pipeDiffLine.sh
#echo @@@@@@@@@@@@@@@@@@@@@@@Two redirects output@@@@@@@@@@@@@@@@@@@@@@
#./timetrash twoRedirectsOutput.sh
echo @@@@@@@@@@@@@@@@@@@@@@@Two subshells@@@@@@@@@@@@@@@@@@@@@@@@@@
./timetrash twoSubshell.sh
