echo this > blah.txt
