cat < /etc/passwd | tr a-z A-Z | sort -u || echo sort failed!
