ls&&ls&&ls
