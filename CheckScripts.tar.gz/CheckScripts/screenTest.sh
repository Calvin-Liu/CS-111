cat notes.txt > f.txt
