(ls&&ls)
