cat notes.txt
| wc
