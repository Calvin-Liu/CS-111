((ls&&ls))
