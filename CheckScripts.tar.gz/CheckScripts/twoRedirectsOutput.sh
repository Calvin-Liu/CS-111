echo this > f.txt > g.txt
