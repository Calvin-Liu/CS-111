cat random.txt | wc
