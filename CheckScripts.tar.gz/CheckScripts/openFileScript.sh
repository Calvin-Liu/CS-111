sort < random.txt
